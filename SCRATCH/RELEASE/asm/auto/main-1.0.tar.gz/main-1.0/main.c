/**
 * @author      : alex (alexbora@gmail.com)
 * @file        : main
 * @created     : Miercuri Noi 16, 2022 09:09:19 EET
 */

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  puts("success");
  return EXIT_SUCCESS;
}
